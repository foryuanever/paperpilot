(() => {
  if (window.__paperSolverCaptureLoaded) return;
  window.__paperSolverCaptureLoaded = true;

  const paper = detectPaper();
  if (!paper || (!paper.doi && !paper.pdfUrl && !hasCitationMeta())) return;
  showPrompt(paper);

  function detectPaper() {
    const url = location.href;
    const title = firstMeta([
      "citation_title",
      "dc.title",
      "DC.Title",
      "og:title",
      "twitter:title"
    ]) || cleanupTitle(document.title);
    const doi = firstMeta([
      "citation_doi",
      "dc.identifier",
      "DC.Identifier",
      "doi"
    ]) || extractDoi(document.body?.innerText || "") || extractDoi(url);
    const pdfUrl = normalizeUrl(
      firstMeta(["citation_pdf_url", "pdf_url"]) ||
      findPdfLink() ||
      (isPdfUrl(url) ? url : "")
    );
    const abstractText = firstMeta([
      "citation_abstract",
      "description",
      "dc.description",
      "og:description"
    ]);
    const authors = allMeta("citation_author").join(", ") ||
      firstMeta(["dc.creator", "DC.Creator", "author"]);
    const year = firstMeta(["citation_publication_date", "citation_online_date", "dc.date"])
      .replace(/^(\d{4}).*$/, "$1");

    return {
      title,
      doi,
      pdfUrl,
      url,
      source: hostLabel(url),
      abstractText,
      authors,
      year
    };
  }

  function showPrompt(paper) {
    const existing = document.getElementById("papersolver-capture-root");
    if (existing) existing.remove();

    const root = document.createElement("div");
    root.id = "papersolver-capture-root";
    root.innerHTML = `
      <div class="ps-card">
        <div class="ps-mark">P</div>
        <div class="ps-main">
          <strong>发现可导入文献</strong>
          <span>${escapeHtml(paper.title || "当前论文页面")}</span>
          <small>${escapeHtml(paper.pdfUrl ? "已识别 PDF 链接" : paper.doi ? `DOI: ${paper.doi}` : paper.source)}</small>
        </div>
        <div class="ps-actions">
          <button type="button" class="ps-import">导入 PaperSolver</button>
          <button type="button" class="ps-close">×</button>
        </div>
      </div>
    `;
    document.documentElement.appendChild(root);
    root.querySelector(".ps-close").addEventListener("click", () => root.remove());
    root.querySelector(".ps-import").addEventListener("click", async () => {
      const button = root.querySelector(".ps-import");
      button.disabled = true;
      button.textContent = "导入中...";
      chrome.runtime.sendMessage({ type: "PAPERSOLVER_IMPORT", payload: paper }, (response) => {
        if (response?.ok) {
          button.textContent = "已导入";
          root.classList.add("ps-success");
          setTimeout(() => root.remove(), 1800);
        } else {
          button.disabled = false;
          button.textContent = "重试导入";
          root.classList.add("ps-error");
        }
      });
    });
  }

  function firstMeta(names) {
    for (const name of names) {
      const selector = [
        `meta[name="${cssEscape(name)}"]`,
        `meta[property="${cssEscape(name)}"]`,
        `meta[name="${cssEscape(name.toLowerCase())}"]`,
        `meta[property="${cssEscape(name.toLowerCase())}"]`
      ].join(",");
      const value = document.querySelector(selector)?.content;
      if (value && value.trim()) return value.trim();
    }
    return "";
  }

  function allMeta(name) {
    return Array.from(document.querySelectorAll(`meta[name="${cssEscape(name)}"]`))
      .map((node) => node.content?.trim())
      .filter(Boolean);
  }

  function findPdfLink() {
    const relPdf = document.querySelector('link[type="application/pdf"], a[type="application/pdf"]')?.href;
    if (relPdf) return relPdf;
    const anchors = Array.from(document.querySelectorAll("a[href]"));
    const directPdf = anchors.find((a) => isPdfUrl(a.href));
    if (directPdf) return directPdf.href;
    const textPdf = anchors.find((a) => /pdf|full text|download/i.test(a.textContent || "") && /pdf|download|article/i.test(a.href));
    return textPdf?.href || "";
  }

  function looksLikePaperPage() {
    return Boolean(
      document.querySelector('meta[name^="citation_"]') ||
      /doi\.org|sciencedirect|semanticscholar|pubmed|webofscience|cnki|wanfang|arxiv|aclanthology|springer|nature|ieee|acm/i.test(location.hostname + location.pathname)
    );
  }

  function hasCitationMeta() {
    return Boolean(document.querySelector('meta[name^="citation_"], meta[name="dc.title"], meta[name="DC.Title"]'));
  }

  function isPdfUrl(url) {
    return /\.pdf($|[?#])|\/pdf\/|arxiv\.org\/pdf\//i.test(url || "");
  }

  function normalizeUrl(url) {
    if (!url) return "";
    try {
      return new URL(url, location.href).href;
    } catch {
      return url;
    }
  }

  function extractDoi(text) {
    return (String(text || "").match(/10\.\d{4,9}\/[-._;()/:A-Z0-9]+/i) || [])[0] || "";
  }

  function cleanupTitle(text) {
    return String(text || "")
      .replace(/\s*[-|]\s*(ScienceDirect|PubMed|Semantic Scholar|Web of Science|CNKI|万方|arXiv).*$/i, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function hostLabel(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch {
      return "官网捕获";
    }
  }

  function cssEscape(value) {
    return String(value).replace(/"/g, '\\"');
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
})();
