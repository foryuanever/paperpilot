const DEFAULT_API_BASE = "http://127.0.0.1:8080";

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ apiBase: DEFAULT_API_BASE });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "PAPERSOLVER_IMPORT") return false;
  importPaper(message.payload)
    .then((result) => {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon-128.svg",
        title: "PaperSolver 导入成功",
        message: result?.title ? `已导入：${result.title}` : "论文已导入文献库"
      });
      sendResponse({ ok: true, result });
    })
    .catch((error) => {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon-128.svg",
        title: "PaperSolver 导入失败",
        message: error?.message || "请确认后端服务已启动"
      });
      sendResponse({ ok: false, error: error?.message || "导入失败" });
    });
  return true;
});

async function importPaper(payload) {
  const { apiBase = DEFAULT_API_BASE } = await chrome.storage.sync.get(["apiBase"]);
  const body = normalizePayload(payload);
  const response = await fetch(`${apiBase.replace(/\/$/, "")}/api/papers/import`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    throw new Error(`后端返回 HTTP ${response.status}`);
  }
  return response.json();
}

function normalizePayload(payload = {}) {
  const title = clean(payload.title) || "未命名论文";
  const source = clean(payload.source) || hostLabel(payload.url || payload.paperUrl || "");
  return {
    source,
    paperId: clean(payload.doi) || clean(payload.paperId) || "",
    paperUrl: clean(payload.pdfUrl) || clean(payload.url) || "",
    title,
    abstractText: clean(payload.abstractText) || "由 PaperSolver Capture 从官网页面导入，摘要待补充。",
    authors: clean(payload.authors) || "",
    publishYear: clean(payload.year) || ""
  };
}

function clean(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function hostLabel(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "官网捕获";
  }
}
