const DEFAULT_API_BASE = "http://127.0.0.1:8080";

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ apiBase: DEFAULT_API_BASE });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "PAPERSOLVER_SAVE_SESSION") {
    saveSession(message.payload)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "账号绑定失败" }));
    return true;
  }
  if (message?.type !== "PAPERSOLVER_IMPORT") return false;
  importPaper(message.payload)
    .then((result) => {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon-128.svg",
        title: "PaperSolver 导入成功",
        message: result?.title ? `已导入：${result.title}` : "论文已导入文献库"
      });
      sendResponse({ ok: true, result });
    })
    .catch((error) => {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon-128.svg",
        title: "PaperSolver 导入失败",
        message: error?.message || "请确认后端服务已启动"
      });
      sendResponse({ ok: false, error: error?.message || "导入失败" });
    });
  return true;
});

async function importPaper(payload) {
  const { apiBase = DEFAULT_API_BASE, userId = "" } = await chrome.storage.sync.get(["apiBase", "userId"]);
  const body = normalizePayload(payload);
  const headers = { "Content-Type": "application/json" };
  if (/^\d+$/.test(String(userId))) {
    headers["X-PaperPilot-User-Id"] = String(userId);
  }
  const response = await fetch(`${apiBase.replace(/\/$/, "")}/api/papers/import`, {
    method: "POST",
    headers,
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    throw new Error(`后端返回 HTTP ${response.status}`);
  }
  const result = await response.json();
  await verifyImported(apiBase, headers, result, body);
  return result;
}

async function verifyImported(apiBase, headers, result, body) {
  const workspaceId = clean(result?.workspaceId);
  if (!workspaceId) {
    throw new Error("后端未返回文献 ID，无法确认是否导入成功");
  }
  const response = await fetch(`${apiBase.replace(/\/$/, "")}/api/library/papers/${encodeURIComponent(workspaceId)}`, {
    method: "GET",
    headers
  });
  if (response.status === 404) {
    throw new Error("后端已响应，但当前账号文献库未找到该论文。请先打开 PaperSolver 页面绑定登录账号。");
  }
  if (!response.ok) {
    throw new Error(`已提交但文献库校验失败 HTTP ${response.status}`);
  }
  const paper = await response.json();
  if (paper?.workspaceId !== workspaceId) {
    throw new Error("导入校验异常，请刷新文献库后确认。");
  }
}

async function saveSession(payload = {}) {
  const userId = clean(payload.userId);
  if (!/^\d+$/.test(userId)) return;
  await chrome.storage.sync.set({
    userId,
    userName: clean(payload.userName),
    appUrl: clean(payload.appUrl)
  });
}

function normalizePayload(payload = {}) {
  const title = clean(payload.title) || "未命名论文";
  const source = clean(payload.source) || hostLabel(payload.url || payload.paperUrl || "");
  return {
    source,
    paperId: clean(payload.doi) || clean(payload.paperId) || "",
    paperUrl: clean(payload.pdfUrl) || clean(payload.url) || "",
    title,
    abstractText: clean(payload.abstractText) || "由 PaperSolver Capture 从官网页面导入，摘要待补充。",
    authors: clean(payload.authors) || "",
    publishYear: clean(payload.year) || ""
  };
}

function clean(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function hostLabel(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "官网捕获";
  }
}
