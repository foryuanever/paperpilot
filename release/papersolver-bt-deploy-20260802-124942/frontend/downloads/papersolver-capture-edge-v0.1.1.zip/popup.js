const input = document.getElementById("apiBase");
const statusEl = document.getElementById("status");

chrome.storage.sync.get(["apiBase"], (data) => {
  input.value = data.apiBase || "http://127.0.0.1:8080";
});

document.getElementById("save").addEventListener("click", () => {
  const value = input.value.trim() || "http://127.0.0.1:8080";
  chrome.storage.sync.set({ apiBase: value }, () => {
    statusEl.textContent = "已保存";
    setTimeout(() => {
      statusEl.textContent = "";
    }, 1600);
  });
});
